# Song Finder

Mobile-friendly music recognition app using AudD.

## Vercel setup
Add an environment variable named `AUDD_API_TOKEN` containing your AudD API token, then deploy.

The API token is never shipped to the browser.
