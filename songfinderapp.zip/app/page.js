"use client";

import { useRef, useState } from "react";

export default function Home() {
  const [status, setStatus] = useState("Tap the button and let me listen for 10 seconds.");
  const [listening, setListening] = useState(false);
  const [result, setResult] = useState(null);
  const mediaRecorder = useRef(null);
  const chunks = useRef([]);

  async function identify() {
    setResult(null);
    try {
      const stream = await navigator.mediaDevices.getUserMedia({ audio: true });
      chunks.current = [];
      const recorder = new MediaRecorder(stream);
      mediaRecorder.current = recorder;

      recorder.ondataavailable = e => {
        if (e.data.size) chunks.current.push(e.data);
      };

      recorder.onstop = async () => {
        stream.getTracks().forEach(t => t.stop());
        setStatus("Identifying…");
        const blob = new Blob(chunks.current, { type: recorder.mimeType || "audio/webm" });
        const form = new FormData();
        form.append("audio", blob, "clip.webm");

        try {
          const res = await fetch("/api/recognize", { method: "POST", body: form });
          const data = await res.json();
          if (!res.ok) throw new Error(data.error || "Recognition failed");
          if (!data.result) {
            setStatus("No match found. Try again closer to the music.");
          } else {
            setResult(data.result);
            setStatus("Found it.");
          }
        } catch (e) {
          setStatus(e.message || "Something went wrong.");
        } finally {
          setListening(false);
        }
      };

      recorder.start();
      setListening(true);
      setStatus("Listening…");
      setTimeout(() => {
        if (recorder.state === "recording") recorder.stop();
      }, 10000);
    } catch {
      setListening(false);
      setStatus("Microphone access is required. Allow microphone access and try again.");
    }
  }

  return (
    <main>
      <section className="card">
        <div className="note">♪</div>
        <h1>Song Finder</h1>
        <p className="sub">{status}</p>
        <button onClick={identify} disabled={listening}>
          {listening ? "Listening…" : "Listen"}
        </button>

        {result && (
          <div className="result">
            <h2>{result.title}</h2>
            <p>{result.artist}</p>
            {result.album && <small>{result.album}</small>}
            <div className="links">
              {result.song_link && <a href={result.song_link} target="_blank">Open song</a>}
            </div>
          </div>
        )}
        <p className="privacy">Audio is recorded only when you tap Listen.</p>
      </section>
    </main>
  );
}